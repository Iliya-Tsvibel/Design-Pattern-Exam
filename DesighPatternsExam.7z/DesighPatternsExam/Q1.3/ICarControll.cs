﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Question3
{
    interface ICarControll
    {
        void Drive();
        void Stop();
        void Accelerate();
        void Slow();
        void TurnRight();
        void TurnLeft();
        float ShowFuelLevel();
        int[] ShowLocation();
    }
}
