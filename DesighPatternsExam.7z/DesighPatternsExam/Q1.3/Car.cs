﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Question3
{
    class Car : ICarControll, ICarIndication
    {
        public void Drive()
        {
            Console.WriteLine("Get out of here dude");
        }

        public void Stop()
        {
            Console.WriteLine("Arrived dude");
        }

        public void Accelerate()
        {
            Console.WriteLine("Accurate, dude, everywhere cops");
        }

        public void Slow()
        {
            Console.WriteLine("Hush comrade, hush");
        }

        public void TurnLeft()
        {
            Console.WriteLine("Left the best whores");
        }

        public void TurnRight()
        {
            Console.WriteLine("Right the best dope");
        }

        public float ShowFuelLevel()
        {
            return 0.75F;
        }

        public int[] ShowLocation()
        {
            return new int[] { 114, 176 };
        }
    }
}
