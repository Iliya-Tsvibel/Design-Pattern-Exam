﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Question3
{
    class Program
    {
        static void Main(string[] args)
        {
            ICarControll myCar = new Car();
            ICarIndication carMonitor = new CarMonitor();

            Console.WriteLine("Car's functions: \n");
            myCar.Drive();
            myCar.Stop();

            Console.WriteLine("\nIndication's functions: \n");

            Console.WriteLine("Fuel: " + carMonitor.ShowFuelLevel());

            Console.Write("Location: ");

            foreach (int cordinate in carMonitor.ShowLocation())
            {
                Console.Write($"{cordinate}, ");
            }
                
            Console.ReadKey();
        }
    }
}
