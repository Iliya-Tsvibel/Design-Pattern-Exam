﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Question3
{
    class CarMonitor : ICarIndication
    {
        public float ShowFuelLevel()
        {
            ICarIndication car = new Car();

            return car.ShowFuelLevel();
        }

        public int[] ShowLocation()
        {
            ICarIndication car = new Car();

            return car.ShowLocation();
        }
    }
}
