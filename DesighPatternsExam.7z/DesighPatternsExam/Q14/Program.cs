﻿using System;
using System.Collections.Generic;

namespace Q14
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] wordsArray = new string[] { "java", "jjava", "vaj", "aavj", "j", "vjaa", "dan", "and", "ddan" }; 

            Dictionary<string, int> output = CountWords(wordsArray);

            foreach(KeyValuePair<string,int> paired in output)
            {
                Console.WriteLine($"The word '{paired.Key}' shows {paired.Value} times.");
            }

            Console.ReadKey();
        }

        /// <summary>
        /// Gets an array of words and return a dictionary of each word and the number of apears in the array.
        /// </summary>
        static Dictionary<string, int> CountWords(string[] word)
        {
            Dictionary<string, int> countWordsDictionary = new Dictionary<string, int>();
            List<string> foundWords = new List<string>();
            List<int> countWords = new List<int>();

            for (int i=0; i < word.Length; i++) 
            {
                bool wordExist = false;

                for (int j=0; j < foundWords.Count; j++) 
                {
                    if (WordsComparing(foundWords[j], word[i])) 
                    {
                        countWords[j]++;
                        wordExist = true;
                    }
                }

                if (!wordExist) 
                {
                    foundWords.Add(word[i]);
                    countWords.Add(1);
                }
            }

            for (int i=0; i < foundWords.Count; i++) 
            {
                countWordsDictionary.Add(foundWords[i], countWords[i]);
            }

            return countWordsDictionary;
        }
    
        static bool WordsComparing(string word1, string word2)
        {
            if (word1.Length == word2.Length) 
            {
                List<int> index = new List<int>(); 
                                                     
                bool wordsMatched = true;

                for (int i = 0; i < word1.Length; i++) 
                {
                    bool matchingLetterExist = false;

                    for (int j = 0; j < word2.Length; j++) 
                    {
                        if (!index.Contains(j))
                        {
                            if (word1.ToCharArray()[i] == word2.ToCharArray()[j])
                            {
                                index.Add(j);
                                matchingLetterExist = true;
                                break;
                            }
                        }
                    }

                    if (!matchingLetterExist)
                    {
                        wordsMatched = false;
                        break;
                    }
                }

                return wordsMatched;
            }

            return false;
        }
    }
}
