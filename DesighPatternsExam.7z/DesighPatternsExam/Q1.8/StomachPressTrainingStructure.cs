﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace P1Q8
{
    class StomachPressTrainingStructure : TrainingStructure
    {
        protected override void ChooseAerobicsPart()
        {
            training.ChooseAerobicsPart("Kicking");
        }

        protected override void ChoosePowerTraining()
        {
            training.ChoosePowerTraining("Abdominal Training");
        }

        protected override void ChooseStretch()
        {
            training.ChooseStretch("Stretching Abdominal Muscles");
        }

        protected override void ChooseTraining()
        {
            training.ChooseTraining("Squats");
        }
    }
}
