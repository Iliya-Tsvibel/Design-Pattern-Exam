﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace P1Q8
{
    public class Training
    {
        private string knockup;
        private string aerobic;
        private string powerTraining;
        private string stretch;
        public Training()
        {
            knockup = null;
            aerobic = null;
            powerTraining = null;
            stretch = null;
        }

        public void ChooseTraining(string warmup)
        {
            if (this.knockup == null)
            {
                this.knockup = warmup;
            }
            else
            {
                throw new InvalidOperationException("Training is already choosen for this training");
            }
        }

        public void ChooseAerobicsPart(string aerobics)
        {
            if (this.aerobic == null)
            {
                this.aerobic = aerobics;
            }
            else
            {
                throw new InvalidOperationException("Aerobics traoining already choosen for this training");
            }
        }

        public void ChoosePowerTraining(string group)
        {
            if (this.powerTraining == null)
            {
                this.powerTraining = group;
            }
            else
            {
                throw new InvalidOperationException("Power Training already choosen for this training");
            }
        }

        public void ChooseStretch(string stretches)
        {
            if (this.stretch == null)
            {
                this.stretch = stretches;
            }
            else
            {
                throw new InvalidOperationException("Stretch already choosen for this training");
            }
        }
    }
}
