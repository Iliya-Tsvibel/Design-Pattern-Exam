﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace P1Q8
{
    public abstract class TrainingStructure
    {
        protected Training training;

        public Training GetTraining()
        {
            return training;
        }

        public void BuildTraining()
        {
            this.training = new Training();

        }

        protected abstract void ChooseTraining();
        protected abstract void ChooseAerobicsPart();
        protected abstract void ChoosePowerTraining();
        protected abstract void ChooseStretch();
    }
}
