﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace P1Q2
{
    class Limb : Element
    {
      
        public Limb(int value) : base(value)
        {
        }

        public Limb(int value, Element parent) : base(value, parent)
        {
        }

        public override void Add(Element element)
        {
            throw new NotSupportedException("Limb element cannot add branch.");
        }

        public override bool CheckIfEven()
        {
            if(val%2 == 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public override void Remove(Element element)
        {
            throw new NotSupportedException("iimb element cannot add branch.");
        }
        public override int Sum()
        {
            int result = this.val;
            Element element = this;
            while (element.general != null)
            {
                element = general;
                result = result + element.val;
            }
            return result;
        }
    }
}
