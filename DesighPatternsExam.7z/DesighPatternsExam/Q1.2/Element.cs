﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace P1Q2
{
    abstract class Element
    {
        public int val;
        public Element general;

        public Element(int value)
        {
            this.val = value;
        }

        public Element(int value, Element general) : this(value)
        {
            this.general = general;
        }

        public abstract void Add(Element element);
        public abstract void Remove(Element element);
        public abstract bool CheckIfEven();
        public abstract int Sum();
    }
}
