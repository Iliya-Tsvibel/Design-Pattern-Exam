﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace P1Q2
{
    class Compound : Element
    {
        private List<Element> _branch = new List<Element>();

     
        public Compound(int value) : base(value)
        {
        }
        public Compound(int value, Element general) : base(value, general)
        {
        }

        public override void Add(Element element)
        {
            if(element.general == this)
            {
                _branch.Add(element);
            }
            else
            {
                throw new InvalidOperationException("Branch parts must point to correct general element.");
            }
        }

        public override bool CheckIfEven()
        {
            while (val%2 == 0)
            {
                foreach (Element child in _branch)
                {
                    if (child.CheckIfEven())
                    {
                        continue;
                    }
                    else
                    {
                        return false;
                    }
                }
                return true;
            }
            return false;
        }

        public override void Remove(Element element)
        {
            if (_branch.Contains(element))
            {
                _branch.Remove(element);
            }
            else
            {
                throw new InvalidOperationException("Part does not contain this element");
            }
        }

        public override int Sum()
        {
            int result = this.val;
            Element element = this;
            while (element.general != null)
            {
                element = general;
                result = result + element.val;
            }
            return result;
        }
    }
}
